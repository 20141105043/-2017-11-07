<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * @property mixed name
 */
abstract class Request extends FormRequest
{
    //
}
